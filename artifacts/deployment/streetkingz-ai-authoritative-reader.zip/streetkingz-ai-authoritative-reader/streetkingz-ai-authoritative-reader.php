<?php
/**
 * Plugin Name: Street Kingz AI Authoritative Reader
 * Description: Narrow, authenticated, read-only product source endpoint for the Street Kingz AI Writer.
 * Version: 1.0.0
 */

defined('ABSPATH') || exit;

const STREETKINGZ_AI_READ_CAPABILITY = 'streetkingz_ai_read_product_source';

register_activation_hook(__FILE__, static function (): void {
    if (!get_role('streetkingz_ai_reader')) {
        add_role('streetkingz_ai_reader', 'Street Kingz AI Reader', [
            'read' => true,
            STREETKINGZ_AI_READ_CAPABILITY => true,
        ]);
    }
});

add_action('rest_api_init', static function (): void {
    register_rest_route('streetkingz-ai/v1', '/products/(?P<id>\d+)/authoritative', [
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => static function () {
            if (!is_user_logged_in() || !current_user_can(STREETKINGZ_AI_READ_CAPABILITY)) {
                return new WP_Error('streetkingz_ai_forbidden', 'This account cannot read authoritative product source.', ['status' => 403]);
            }
            return true;
        },
        'callback' => 'streetkingz_ai_read_authoritative_product',
        'args' => [
            'id' => ['required' => true, 'type' => 'integer', 'minimum' => 1],
        ],
    ]);
});

function streetkingz_ai_raw_meta_value(int $post_id, string $key): array {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT meta_id, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s ORDER BY meta_id ASC",
        $post_id,
        $key
    ), ARRAY_A);
    if (!$rows) {
        return ['present' => false, 'row_count' => 0, 'raw_stored_value' => null];
    }
    return ['present' => true, 'row_count' => count($rows), 'raw_stored_value' => $rows[0]['meta_value']];
}

function streetkingz_ai_read_authoritative_product(WP_REST_Request $request) {
    global $wpdb;
    $post_id = (int) $request['id'];
    $post = $wpdb->get_row($wpdb->prepare(
        "SELECT ID, post_type, post_status, post_title, post_excerpt, post_content, post_name FROM {$wpdb->posts} WHERE ID = %d LIMIT 1",
        $post_id
    ), ARRAY_A);
    if (!$post) {
        return new WP_Error('streetkingz_ai_product_not_found', 'Product not found.', ['status' => 404]);
    }
    if ($post['post_type'] !== 'product') {
        return new WP_Error('streetkingz_ai_not_product', 'The requested post is not a product.', ['status' => 400]);
    }

    $elementor = streetkingz_ai_raw_meta_value($post_id, '_elementor_data');
    $edit_mode = streetkingz_ai_raw_meta_value($post_id, '_elementor_edit_mode');
    $template_type = streetkingz_ai_raw_meta_value($post_id, '_elementor_template_type');
    $version = streetkingz_ai_raw_meta_value($post_id, '_elementor_version');

    return rest_ensure_response([
        'schema_version' => 1,
        'product' => [
            'id' => (int) $post['ID'],
            'post_type' => $post['post_type'],
            'post_status' => $post['post_status'],
            'post_title' => $post['post_title'],
            'post_excerpt' => $post['post_excerpt'],
            'post_content' => $post['post_content'],
            'post_name' => $post['post_name'],
            'permalink' => get_permalink($post_id),
        ],
        'elementor' => [
            'raw_data' => $elementor['raw_stored_value'],
            'raw_data_present' => $elementor['present'],
            'raw_data_row_count' => $elementor['row_count'],
            'parsed_data' => $elementor['present'] ? json_decode($elementor['raw_stored_value'], true) : null,
            'edit_mode' => $edit_mode['raw_stored_value'],
            'template_type' => $template_type['raw_stored_value'],
            'version' => $version['raw_stored_value'],
        ],
    ]);
}
